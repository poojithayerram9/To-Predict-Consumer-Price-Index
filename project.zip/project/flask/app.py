from flask import Flask, request, jsonify, render_template
import pandas as pd
import numpy as np
import pickle

app = Flask(__name__)

# Load the trained model
model = None
with open('model.pkl', 'rb') as f:
    model = pickle.load(f)

# Column names and expected data types for validation
expected_columns = {
    'Sector': np.int64,
    'Year': np.int64,
    'Month': np.int64,
    'Cereals and products': np.float64,
    'Meat and fish': np.float64,
    'Egg': np.float64,
    'Milk and products': np.float64,
    'Oils and fats': np.float64,
    'Fruits': np.float64,
    'Vegetables': np.float64,
    'Pulses and products': np.float64,
    'Sugar and Confectionery': np.float64,
    'Spices': np.float64,
    'Non-alcoholic beverages': np.float64,
    'Prepared meals, snacks, sweets etc.': np.float64,
    'Food and beverages': np.float64,
    'Pan, tobacco and intoxicants': np.float64,
    'Clothing': np.float64,
    'Footwear': np.float64,
    'Clothing and footwear': np.float64,
    'Housing': np.float64,
    'Fuel and light': np.float64,
    'Household goods and services': np.float64,
    'Health': np.float64,
    'Transport and communication': np.float64,
    'Recreation and amusement': np.float64,
    'Education': np.float64,
    'Personal care and effects': np.float64,
    'Miscellaneous': np.float64,
    'General index': np.float64
}

# Route for home page
@app.route('/')
def home():
    return render_template('home.html')

# Route for prediction form
@app.route('/index')
def index():
    return render_template('index.html')

# Define a route to predict based on incoming data
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Extract JSON data from request
        json_data = request.get_json()

        # Validate incoming data against expected columns
        for col, dtype in expected_columns.items():
            if col not in json_data:
                return jsonify({'error': f'Missing column {col} in input data'})
            if not isinstance(json_data[col], dtype):
                return jsonify({'error': f'Invalid type for column {col}. Expected {dtype}'})

        # Convert JSON to DataFrame
        data = pd.DataFrame(json_data, index=[0])

        # Make prediction
        prediction = model.predict(data)

        # Render result template with prediction
        return render_template('result.html', prediction=prediction[0])

    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
